package com.scalessec.coloroptions;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class ColorOptionsActivity extends Activity {
   
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.options, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		TextView textView = (TextView)findViewById(R.id.textView);
		View root = textView.getRootView();
		
		switch (item.getItemId()) {
		case R.id.red:
			root.setBackgroundColor(Color.RED);
			return true;

		case R.id.yellow:
			root.setBackgroundColor(Color.YELLOW);
			return true;

		case R.id.green:
			root.setBackgroundColor(Color.GREEN);
			return true;

		case R.id.cyan:
			root.setBackgroundColor(Color.CYAN);
			return true;

		case R.id.blue:
			root.setBackgroundColor(Color.BLUE);
			return true;

		case R.id.magenta:
			root.setBackgroundColor(Color.MAGENTA);
			return true;

		case R.id.gray:
			root.setBackgroundColor(Color.GRAY);
			return true;

		case R.id.black:
			root.setBackgroundColor(Color.BLACK);
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}

    
}